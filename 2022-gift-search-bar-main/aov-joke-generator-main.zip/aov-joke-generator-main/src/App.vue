<template>
  <div class="w-full h-full flex justify-center items-center">
    <span class="text-3xl">Good luck!</span>
  </div>
</template>

<script setup>
// fetch('https://v2.jokeapi.dev/joke/christmas') ...
</script>
