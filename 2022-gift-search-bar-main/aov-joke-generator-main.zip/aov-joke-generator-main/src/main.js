import { createApp } from 'vue'
import App from './App.vue'
import './base.css'

createApp(App).mount('#app')
